## Authors

### Lead

-   Nathan Cahill @nathancahill

### Contributors

-   Rod Montgomery @RodMontgomery
-   pedrogit @pedrogit
-   Özgür Uysal @ozguruysal
-   Sánta Gergely @gsanta
-   Basil Musa @basilmusa
-   justdoo @justdoo
-   Jacque Goupil @DominoPivot
-   Max Waterman @davidmaxwaterman
-   Basarat Ali Syed @basarat
-   Adam Jimenez @adamjimenez
-   @ambischof
-   Kushagra Gour @chinchang
-   TIm St.Clair @frumbert
-   Turkhan @turok1997
-   @SCrusader
-   OpenCollective @opencollective
-   David Evans @davidje13
-   @saluce65
-   Peter Lightbody @pet1330
-   Jakob Gillich @jgillich
-   Searene @searene
-   Gabriel Pedro @gpedro
-   Chi Wang @patr0nus
-   Adrian Jones @adrianbj
-   Bradley Kemp @bradleyjkemp
